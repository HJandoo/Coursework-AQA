jWMI Release 1.0
================

This software is copyright 2009-2010 HenryRanch LLC.  All rights reserved.  
See the license.txt file for license information.

Source and binary code are contained in their respective directories.

To execute: 
1. cd into bin directory
2. run: java com.citumpe.ctptools.jWMI [<wmiQuery> <commaSeparatedListOfDesiredFields>]